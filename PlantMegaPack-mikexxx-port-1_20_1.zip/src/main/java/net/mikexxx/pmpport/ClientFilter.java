package net.mikexxx.pmpport;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

/** Colour filter buttons on the left side of the creative screen while the PMP "All Plants" tab is open. */
@Mod.EventBusSubscriber(modid = PmpMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientFilter {
    private static final String[] KEYS = {"all", "burgundy", "red", "orange", "yellow", "green", "blue", "cyan", "purple", "pink", "white", "other"};
    private static final String[] ICONS = {"minecraft:peony", "item_flower_torch_ginger", "flower_red", "flower_ora", "flower_yel", "flower_grn",
            "flower_blu", "flower_cya", "flower_pur", "flower_pnk", "flower_wht", "minecraft:brown_dye"};

    private static String active = "all";
    private static boolean wasOurTab = false;

    private static ItemStack icon(String id) {
        ResourceLocation rl = id.contains(":") ? new ResourceLocation(id) : new ResourceLocation(PmpMod.MODID, id);
        Item it = ForgeRegistries.ITEMS.getValue(rl);
        return new ItemStack(it == null || it == Items.AIR ? Items.OAK_SAPLING : it);
    }

    private static boolean ourTabSelected() {
        try {
            for (Field f : CreativeModeInventoryScreen.class.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers()) && f.getType() == CreativeModeTab.class) {
                    f.setAccessible(true);
                    CreativeModeTab tab = (CreativeModeTab) f.get(null);
                    if (tab == null) return false;
                    ResourceLocation key = BuiltInRegistries.CREATIVE_MODE_TAB.getKey(tab);
                    return key != null && key.getNamespace().equals(PmpMod.MODID) && key.getPath().equals("all_plants");
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    /** resets the highlighted filter when the tab gets (re)opened, because vanilla refills the full list then */
    private static boolean checkTab() {
        boolean now = ourTabSelected();
        if (now && !wasOurTab) active = "all";
        wasOurTab = now;
        return now;
    }

    private static void apply(CreativeModeInventoryScreen screen, String key) {
        active = key;
        List<ItemStack> stacks = new ArrayList<>();
        for (String id : ColorConfig.category(key)) {
            Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(PmpMod.MODID, id));
            if (it != null && it != Items.AIR) stacks.add(new ItemStack(it));
        }
        CreativeModeInventoryScreen.ItemPickerMenu menu = screen.getMenu();
        menu.items.clear();
        menu.items.addAll(stacks);
        menu.scrollTo(0.0F);
        try {
            for (Field f : CreativeModeInventoryScreen.class.getDeclaredFields()) {
                if (!Modifier.isStatic(f.getModifiers()) && f.getType() == float.class) {
                    f.setAccessible(true);
                    f.setFloat(screen, 0.0F);
                    break;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static class FilterButton extends Button {
        private final String key;
        private final ItemStack icon;

        FilterButton(int x, int y, String key, ItemStack icon, CreativeModeInventoryScreen screen) {
            super(x, y, 20, 20, Component.empty(), b -> apply(screen, key), Button.DEFAULT_NARRATION);
            this.key = key;
            this.icon = icon;
            this.setTooltip(Tooltip.create(Component.translatable("pmp_mikexxx.filter." + key)));
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partial) {
            if (!checkTab()) return;
            super.renderWidget(g, mouseX, mouseY, partial);
            g.renderItem(icon, this.getX() + 2, this.getY() + 2);
            if (key.equals(active)) {
                g.fill(this.getX(), this.getY() + 18, this.getX() + 20, this.getY() + 20, 0xFFFFFF55);
            }
        }

        @Override
        public boolean mouseClicked(double x, double y, int button) {
            return ourTabSelected() && super.mouseClicked(x, y, button);
        }
    }

    @SubscribeEvent
    public static void onInit(ScreenEvent.Init.Post event) {
        if (!(event.getScreen() instanceof CreativeModeInventoryScreen screen)) return;
        int left = screen.getGuiLeft();
        int top = screen.getGuiTop();
        for (int i = 0; i < KEYS.length; i++) {
            int col = i % 2;
            int row = i / 2;
            int x = left - 46 + col * 22;
            int y = top + 4 + row * 22;
            event.addListener(new FilterButton(x, y, KEYS[i], icon(ICONS[i]), screen));
        }
    }
}

package net.mikexxx.pmpport;

import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.GrassColor;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.Map;

/**
 * Tints the (grey) leaf textures with the fixed per-tree colour of the original mod,
 * for the placed block and for the inventory item. The colour is the same everywhere (not biome dependent).
 */
@Mod.EventBusSubscriber(modid = PmpMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientColors {
    @SubscribeEvent
    public static void blockColors(RegisterColorHandlersEvent.Block e) {
        for (Map.Entry<String, Integer> en : PmpMod.LEAF_TINT.entrySet()) {
            Block b = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(PmpMod.MODID, en.getKey()));
            if (b == null) continue;
            final int c = en.getValue();
            e.register((state, level, pos, tintIndex) -> c, b);
        }
        for (String id : PmpMod.BIOME_TINT) {
            Block b = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(PmpMod.MODID, id));
            if (b == null) continue;
            e.register((state, level, pos, tintIndex) -> level != null && pos != null
                    ? BiomeColors.getAverageGrassColor(level, pos) : GrassColor.get(0.5D, 1.0D), b);
        }
    }

    @SubscribeEvent
    public static void itemColors(RegisterColorHandlersEvent.Item e) {
        for (Map.Entry<String, Integer> en : PmpMod.LEAF_TINT.entrySet()) {
            net.minecraft.world.item.Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(PmpMod.MODID, en.getKey()));
            if (it == null) continue;
            final int c = en.getValue();
            e.register((stack, tintIndex) -> c, it);
        }
        for (String id : PmpMod.BIOME_TINT) {
            net.minecraft.world.item.Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(PmpMod.MODID, id));
            if (it == null) continue;
            e.register((stack, tintIndex) -> GrassColor.get(0.5D, 1.0D), it);
        }
    }
}
